﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maui.cop4870.ViewModels
{
    internal class MainViewModel
    {
        public string Display
        {
            get
            {
                return "Hello World";
            }
        }
    }
}
